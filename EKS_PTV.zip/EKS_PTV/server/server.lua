RegisterNetEvent('eks_cell:toggleLock', function(netId, state)
    local src = source
    if type(netId) ~= 'number' then return end

    local entity = NetworkGetEntityFromNetworkId(netId)
    if not entity or entity == 0 or not DoesEntityExist(entity) then return end

    local ent = Entity(entity)
    if not ent then return end

    ent.state:set('cellLocked', state, true)

    local coords = GetEntityCoords(entity)
    TriggerClientEvent('eks_cell:playLockSound', -1, coords)
end)
