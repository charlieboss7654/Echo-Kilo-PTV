Config = {}

-- Vehicles and their specific cell doors
-- Door indexes:
-- 0 = Front Left, 1 = Front Right
-- 2 = Rear Left, 3 = Rear Right
-- 4 = Hood, 5 = Trunk/Boot

Config.CellVehicles = {
    ['policet'] = {2, 3},   
    ['police2'] = {2, 3, 5} 
}
