local function getDoorsForVehicle(vehicle)
    local model = GetEntityModel(vehicle)
    for veh, doors in pairs(Config.CellVehicles) do
        if model == joaat(veh) then
            return doors
        end
    end
    return nil
end

local function areDoorsOpen(vehicle, doors)
    for _, doorIndex in ipairs(doors) do
        if GetVehicleDoorAngleRatio(vehicle, doorIndex) <= 0.1 then
            return false
        end
    end
    return true
end

local function isBehindVehicle(entity, coords, dist)
    local vehCoords = GetEntityCoords(entity)
    local forward = GetEntityForwardVector(entity)
    local rear = vehCoords - forward * 3.0
    return #(coords - rear) < (dist or 3.0)
end

local function isLocked(entity)
    local st = Entity(entity).state
    return st and st.cellLocked or false
end

local function seatsFromDoors(doors)
    local seats = {}
    for _, d in ipairs(doors) do
        if d == 0 then seats[-1] = true
        elseif d == 1 then seats[0] = true
        elseif d == 2 then seats[1] = true
        elseif d == 3 then seats[2] = true
        end
    end
    return seats
end

RegisterNetEvent('eks_cell:playLockSound', function(atCoords)
    local my = GetEntityCoords(PlayerPedId())
    if #(my - atCoords) <= 25.0 then
        SendNUIMessage({ action = 'play', sound = 'doorlock' })
    end
end)

CreateThread(function()
    while true do
        local wait = 500
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 then
                local doors = getDoorsForVehicle(veh)
                if doors and isLocked(veh) then
                    wait = 0
                    local lockedSeats = seatsFromDoors(doors)
                    for seatIndex, _ in pairs(lockedSeats) do
                        if GetPedInVehicleSeat(veh, seatIndex) == ped then
                            DisableControlAction(0, 75, true)  
                            DisableControlAction(27, 75, true)
                            if not IsPedUsingActionMode(ped) and IsPedTryingToEnterALockedVehicle(ped) then
                                ClearPedTasks(ped)
                            end
                            break
                        end
                    end
                end
            end
        end
        Wait(wait)
    end
end)

CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local pcoords = GetEntityCoords(ped)
        local veh = GetVehiclePedIsIn(ped, false)

        if veh ~= 0 and DoesEntityExist(veh) and isLocked(veh) then
            local doors = getDoorsForVehicle(veh)
            if doors then
                for _, d in ipairs(doors) do
                    if GetVehicleDoorAngleRatio(veh, d) > 0.0 then
                        SetVehicleDoorShut(veh, d, false)
                    end
                end
            end
        end

        Wait(400)
    end
end)

exports.ox_target:addGlobalVehicle({
    {
        name = 'cell_doors_open',
        icon = 'fa-solid fa-door-open',
        label = 'Open Cell Doors',
        canInteract = function(entity, distance, coords)
            local doors = getDoorsForVehicle(entity)
            if not doors then return false end
            if isLocked(entity) then return false end
            if not isBehindVehicle(entity, coords, 3.0) then return false end
            return not areDoorsOpen(entity, doors)
        end,
        onSelect = function(data)
            local veh = data.entity
            local doors = getDoorsForVehicle(veh)
            if not doors or isLocked(veh) then return end
            for _, doorIndex in ipairs(doors) do
                SetVehicleDoorOpen(veh, doorIndex, false, false)
            end
            lib.notify({ title = 'Cell Doors', description = 'Doors Opened', type = 'inform' })
        end
    },

    {
        name = 'cell_doors_close',
        icon = 'fa-solid fa-door-open',
        label = 'Close Cell Doors',
        canInteract = function(entity, distance, coords)
            local doors = getDoorsForVehicle(entity)
            if not doors then return false end
            if isLocked(entity) then return false end
            if not isBehindVehicle(entity, coords, 3.0) then return false end
            return areDoorsOpen(entity, doors)
        end,
        onSelect = function(data)
            local veh = data.entity
            local doors = getDoorsForVehicle(veh)
            if not doors then return end
            for _, doorIndex in ipairs(doors) do
                SetVehicleDoorShut(veh, doorIndex, false)
            end
            lib.notify({ title = 'Cell Doors', description = 'Doors Closed', type = 'inform' })
        end
    },

    {
        name = 'cell_doors_lock',
        icon = 'fa-solid fa-lock',
        label = 'Lock Cell Door',
        canInteract = function(entity, distance, coords)
            local doors = getDoorsForVehicle(entity)
            if not doors then return false end
            if not isBehindVehicle(entity, coords, 3.0) then return false end
            return not isLocked(entity)
        end,
        onSelect = function(data)
            local veh = data.entity
            local doors = getDoorsForVehicle(veh)
            if not doors then return end
            for _, d in ipairs(doors) do SetVehicleDoorShut(veh, d, false) end
            TriggerServerEvent('eks_cell:toggleLock', VehToNet(veh), true)
            lib.notify({ title = 'Cell Doors', description = 'Cell locked', type = 'warning' })
        end
    },

    {
        name = 'cell_doors_unlock',
        icon = 'fa-solid fa-lock-open',
        label = 'Unlock Cell Door',
        canInteract = function(entity, distance, coords)
            local doors = getDoorsForVehicle(entity)
            if not doors then return false end
            if not isBehindVehicle(entity, coords, 3.0) then return false end
            return isLocked(entity)
        end,
        onSelect = function(data)
            local veh = data.entity
            local doors = getDoorsForVehicle(veh)
            if not doors then return end
            TriggerServerEvent('eks_cell:toggleLock', VehToNet(veh), false)
            lib.notify({ title = 'Cell Doors', description = 'Cell unlocked', type = 'inform' })
        end
    }
})
