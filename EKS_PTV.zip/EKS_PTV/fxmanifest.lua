fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'R.Robertson - Echo Kilo Studios'
ui_page 'html/index.html'

shared_script '@ox_lib/init.lua'

dependency 'ox_lib'
dependency 'ox_target'

client_scripts {
    'config.lua',
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

files {
    'html/index.html',
    'html/sounds/doorlock.ogg'
}
